#!/bin/sh

#PERLPATH=/home/dream_burn_uboot/perl_modules
CONFIGPATH=/home/dream_burn_uboot/configs
#RPMPATH=/home/dream_burn_uboot/rpms-f11					
TESTENVPATH=/home/dream_burn_uboot
MINICOMPATH=/home/dream_burn_uboot/rpm_minicom
OPENOCDPATH=/home/dream_burn_uboot/rpm_openocd

# install minirc.marvell
cp -f $CONFIGPATH/minirc.marvell /etc/minirc.marvell 

# installl rpms as dependencies 

#cd /home
#rpm -ivh $RPMPATH/xinetd-2.3.14-22.fc11.i586.rpm
#rpm -ivh $RPMPATH/tftp-server-0.49-3.fc11.i586.rpm 
#rpm -ivh $RPMPATH/libusb-devel-0.1.12-21.fc11.i586.rpm --ignorearch
#rpm -ivh $RPMPATH/libftdi-devel-0.15-4.fc11.i586.rpm $RPMPATH/libftdi-0.15-4.fc11.i586.rpm --ignorearch
#rpm -ivh $RPMPATH/tcl-8.5.6-6.fc11.i586.rpm --ignorearch
#rpm -ivh $RPMPATH/lrzsz-0.12.20-26.fc11.i586.rpm   $RPMPATH/minicom-2.3-4.fc11.i586.rpm --ignorearch
rpm -ivh $MINICOMPATH/lrzsz-0.12.20-27.fc12.i686.rpm   $MINICOMPATH/minicom-2.4-2.fc14.i686.rpm
rpm -ivh $OPENOCDPATH/libftdi-0.18-3.fc14.i686.rpm  $OPENOCDPATH/openocd-0.4.0-1.fc14.i686.rpm

# configure tftpserver

#cp -f $CONFIGPATH/tftp /etc/xinetd.d/
#cp $TESTENVPATH/uImage-plug2 /var/lib/tftpboot/

# tftp write permission as well.
#chown nobody:nobody /var/lib/tftpboot/
#chmod ug+rwx /var/lib/tftpboot/

# install perl modules - IO:tty, Expect

#tar zxvf $PERLPATH/IO-Tty-1.08.tar.gz 
#cd IO-Tty-1.08/
#perl Makefile.PL 
#make
#make install
#cd ..

#tar zxvf $PERLPATH/Expect-1.21.tar.gz 
#cd Expect-1.21/
#perl Makefile.PL 
#make
#make install
#cd ..

#rm -rf IO-Tty-1.08/ Expect-1.21/

# configure NFS
#mkdir /nfs
#cd /nfs
#tar zxvf $TESTENVPATH/rootfs.tar.gz
#mv /nfs/rootfsv1.0 /nfs/rootfs/
#cp -f $CONFIGPATH/exports /etc/exports 
#chkconfig --level 35 nfs on

# copy nand(ubifs) filesystem to NFS root so that diag script can use them later
#cp $TESTENVPATH/rootfs.ubi.img /nfs/rootfs/
#cp $TESTENVPATH/uImage-plug2 /nfs/rootfs/

# copy openrd directory containing - diag.pl, openocd
#cp -R $TESTENVPATH/openrd/ /home/
#changed by Ellin
# copy sheevaplug directory containing - diag.pl, openocd
cp -R $TESTENVPATH/sheevaplug/ /home/         
cp -R $TESTENVPATH/uboot_test_suite/ /home/ 
  
# configure workstation to call /home/openrd/loadftdi.sh at boot-time 

cp $CONFIGPATH/rc.local /etc/rc.local

# restart xinetd.d (redundant)
#/etc/init.d/xinetd restart

#echo "Please make sure selinux is disabled on this machine for nfs & tftp to work"
#echo "Please reboot system for settings to take effect"
echo "===== Environment for DreamPlug Install Complete! ====="
