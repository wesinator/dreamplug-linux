############################################################################################
README file for U-boot test suite

Author :
	Piyush Shah (spiyush@marvell.com)
Log :
	21.11.08 	Piyush Shah 	Created for the first version of the test suite
############################################################################################
CONTENTS :
==========
1)		: SUMMARY
2)		: CODE STRUCTURE
			1.ubootTest.tcl
			2.uboot_test_xx.tcl
			3.Library
3)		: TEST FILES
4)		: DIRECTIVES
5) 		: CONFIG FILE
6)		: COMMAND LINE OPTIONS
7)		: RULES FOR ADDING NEW SCRIPTS
8)		: HOW TO USE THE TEST SUITE
############################################################################################

1) SUMMARY :
============
 This README file gives details regarding the structure of the Automated U-boot test suite
 It explains the purpose of each file and the procedures contained in it. This document also
 explains how to use the test suite. All the scripts are written for Tcl.

2) CODE STRUCTURE :
===================
 This directory consists of :

 ubootTest.tcl		The main script to be executed to carry out all the tests
 
 uboot_test_xx.txt	The test file which tells the code what all tests need to be
 			performed xx represents the test class. Eg. For UBOOT_TEST_03
 			test class, the test file name will be test_03.txt
 			
 lib/			A folder which contains all the library files used by the test suite

2.1) ubootTest.tcl :
====================
 This script carries out the following tasks :

2.1.1) Initialising the serial port:
------------------------------------
 The port to be used is specified in the variable "comPort"
 The baud rate to be used is specified in the "baudrate" variable.
 These may need modifications prior to beginning the tests as per the serial port name 
 of your machine and the baud rate being used by the Device Under Test (DUT)
 The port is closed after the tests end

2.1.2) Initialising global variables :
--------------------------------------
 dir 		Holds the path name of the library files. It is used to create a database of
 		the packages(pkgIndex.tcl) using the pkg_mkIndex command and then use it for 
 		loading various packages

 gOutput 	Is used by some procedures to store the results of some operations even
		when the operation has returned with an error

 lastline	Holds the last line of the result of any command, if the get_result() procedure
		is used. It is used by some procedures to make sense out of the command output

 boot_prompt 	The prompt to be searched for when the u-boot loads and autoboot is	
		stopped. Is is also used to check whether a given u-boot command has
		completed and the prompt has reappeared

 no_prompt 	Is set to 1 initially and reset to 0 once we get the boot_prompt.
		Is again set to 1, when it is realised that U-boot has hanged or the
		DUT has been switched off so that the tests can be stopped

 fd_tftp_log 	File descriptor for the tftp_log.txt file which holds the actual results
		of all the tftp commands

 fd 		This descriptor holds the channel id of the serial port and is used for
		all the communication over the serial link

 fd_cmd_log 	File descriptor for the command_log.txt file which is the log of all the
		commands sent out to the DUT. The log file is opened and closed by the
		ubootTest.tcl script itself

 test_name 	Holds the name of the test being currently performed. This name is then
		written into the output results_xx.txt file

 boot_page 	Holds the result of the bootstartdata which compulsorily needs to be
		called at the beginning of the tests before the DUT is turned on.
		The data it holds is used by UBOOT_TEST_01 since it contains all the
		relevant information regarding the DUT

 tftpfilename	Holds the filename to be used for TFTP tests

 auto		Decides whether to use custom testfiles or use the files from the library
		which have all the important tests

 serverip	The serverip to be used for tftp tests if it is not provided in the test file

 bytes_transferred  When any tftp command is successful, this variable holds the number of
		bytes transferred via tftp

 uboot_test_01/02/03/04/05/06/07  A value of 0 means that the tests in that particular test
	class are not to be performed

 flash_mem_addr  The flash memory address to be used for flash memory copy tests


2.1.3) Calling procedures for each test class :
-----------------------------------------------
 Searches the working directory for test files corresponding to each test class and
 calls its procedure if the file exists

2.2) uboot_test_xx.txt :
========================
 xx denotes the test class to which this file belongs. Eg. For UBOOT_TEST_03, the test
 file will have the name uboot_test_03.txt
 It consists a list of all the tests to be performed alongwith the arguments, if required.
 It may also contain directives like set, save, delete, reset, cmd
 (The details of these directives are covered later)
 The testcaseids as per the uboot test plan are used rather than the test names
 Eg. To carry out UBOOT_TEST_04_04 : Network(Ping) test, the uboot_test_04.txt file
 must have this line :
 
 UBOOT_TEST_04_04 IpAddr
 
 The argument IpAddr (Which must be replaced by the actual IP address of the machine to 
 be pinged) is used to setup the argument for the ping command to be executed
 
 Many tests do not require any arguments at all. Hence only writing the testcaseid will
 suffice. Note that, each test case must occupy a single line in the test file and no
 two test cases can be declared on the same line
 
 2.3) lib/ :
 ===========
 This folder contains all the library files, each containing a single Tcl package which
 can be loaded by other packages as per the requirement. Each file has a small description
 of what it is meant for. The package, in turn, contains one or more procedures(proc)
 which can be called after the package for that procedure is loaded successfully. The
 code of each proc is preceded by its summary i.e. the purpose of that proc, parameters
 it requires, return value and general comments. All the library files and the packages
 they provide are summarized below:
 (Note : The summary of each proc can be found in the respective file)
 
 2.3.1) mv_serial_port.tcl :
 ===========================
 provides package 	:mv_serial_port
 requires package 	:N/A
 This package contains procs to handle serial communication which involves initialising
 the port, sending data, receiving data, closing port, etc.The various procs it contains
 are :
 
 mv_serialPortSetup 	:Sets up the serial port with the parameters sent to it
 mv_comPortGetData 	:Gets data from the serial port
 mv_comPortSendCmd 	:Sends a command to the serial port
 mv_comPortClose 	:Closes the serial port
 
  2.3.2) mv_uboot_utils.tcl :
 ===========================
 provides package 	:mv_uboot_utils
 requires package 	:mv_serial_port
 This package contains procs which are used by almost all the other packages in the test
 suite. These are very important procedures.
 
 bootstartdata 		:This proc captures the characters received as the u-boot
 			loads and sends a new line character to stop autoboot and get
 			the U-boot prompt
 get_result		:This proc captures the results of any command, till the prompt
 			or any other expected data appears or till a timeout 
 search_data 		:This proc searches the input given by a particular channel
	 		for a given string
 isdirective		:This proc handles various directives
 clean			:This proc deletes all the files generated as the result of any
 			previous tests
 command_line_args	:This procedure handles the command line arguments if any, like baud, auto,
 			boot_prompt,etc
 generate_result	:This procedure combines the results of all the tests and puts them into a
 			single file
 			
 2.3.3) mv_uboot_test_03.tcl :
 =============================
 provides package 	:mv_uboot_test_03
 requires package 	:mv_serial_port
 			:mv_uboot_utils
 This package contains procedures to handle tests in UBOOT_TEST_03 test class listed in
 the uboot_test_03.txt file. These procedures are:
 
 test_03_info 		:This proc accepts a test case id and returns a suitable string
 			which decides the further course of action
 uboot_test_03 		:This proc calls various procedures required to carry out all
 			the tests in UBOOT_TEST_03 class
  			Directives if any are handled by calling the isdirective proc
 2.3.4) mv_flashtest.tcl :
 =========================
 provides package	:mv_flashtest
 requires package 	:mv_serial_port
 		 	:mv_uboot_utils
 
 This package is needed for UBOOT_TEST_03_08 : Flash memory test. It consist of a single
 procedure
 
 flashtest		:This proc checks the availability of flash memory on the board
 			and stores the results in flashinfo.txt file

 2.3.5) mv_nandtest.tcl :
 ========================
 provides package	:mv_nandtest
 requires package	:mv_serial_port
 			:mv_uboot_utils
 This package is needed for UBOOT_TEST_03_09 : Nand memory test. It consist of a single
 procedure
 
 nandtest		:This proc checks the availability of flash memory on the board
 			and stores the results in flashinfo.txt file
 			
 2.3.6) mv_uboot_test_04.tcl :
 =============================
 provides package	:mv_uboot_test_04
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_env_test_01 {only if UBOOT_TEST_04_01 is to be performed}
  			:mv_env_test_02 {only if UBOOT_TEST_04_02 is to be performed}
  			:mv_linktest {only if UBOOT_TEST_04_03 is to be performed}
  			:mv_network_test {only if UBOOT_TEST_04_04 is to be performed}
  			:mv_dhcp_test {only if UBOOT_TEST_04_05 is to be performed}
  			:mv_tftptest {only if UBOOT_TEST_04_06 is to be performed}
  			:mv_boot {only if UBOOT_TEST_04_08 is to be performed}
 This package contains procedures to handle tests in UBOOT_TEST_04 test class listed
 in the uboot_test_04.txt file. These procedures are:
 test_04_info 		:This proc accepts a test case id and returns a suitable string
 			which decides the further course of action
 uboot_test_04 		:This proc calls various procedures required to carry out all
 			the tests in UBOOT_TEST_04 class
 			Directives if any are handled by calling the isdirective proc
 			
 2.3.7) mv_environment.tcl :
 ===========================
 provides package 	:mv_environment
 requires package	:mv_serial_port
 			:mv_uboot_utils
 This package provides procedures to handle environment variables in U-boot. The various
 procedures are :
 set_env		:This proc accepts a variable name and value and creates/modifies
 			the corresponding environment variable in u-boot
 save_env		:This proc saves the environment to non-volatile memory
 reset			:This proc resets the board, stopping at the prompt (This proc
 			is not directly related to environment though)
 delete_env		:This proc accepts a variable name and deletes it from the u-boot
			environment
 get_env		:This proc accepts a variable name, searches the u-boot
 			environment for it and if found returns its value
 			
 2.3.8) mv_test_env_01.tcl :
 ===========================
 provides package	:mv_test_env_01
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_environment
 This package provides procedures for UBOOT_TEST_04_01. These are :
 env_test_01_01		:This proc carries out Environment variables Test 1.1
 			(UBOOT_TEST_04_01_01)
 env_test_01_02		:This proc carries out Environment variables Test 1.2
 			(UBOOT_TEST_04_01_02)
 env_test_01_03		:This proc carries out Environment variables Test 1.3
 			(UBOOT_TEST_04_01_03)
 env_test_01		:This proc carries out Environment variables Test 1
 			(UBOOT_TEST_04_01). It calls one of the above three procedures
 			depending on the sub-test case id provided
 			
 2.3.9) mv_test_env_02.tcl :
 ===========================
 provides package	:mv_test_env_02
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_environment
 This package provides procedures for UBOOT_TEST_04_02. These are :
 env_test_02_01		:This proc carries out Environment variables Test 2.1
 			(UBOOT_TEST_04_02_01)
 env_test_02_02		:This proc carries out Environment variables Test 2.2
 			(UBOOT_TEST_04_02_02)
 env_test_02_03		:This proc carries out Environment variables Test 2.3
 			(UBOOT_TEST_04_02_03)
 env_test_02		:This proc carries out Environment variables Test 2
 			(UBOOT_TEST_04_02). It calls one of the above three procedures
 			depending on the sub-test case id provided
 			
 2.3.10) mv_linktest.tcl :
 =========================
 provides package 	:mv_linktest
 requires package 	:mv_serial_port
 			:mv_uboot_utils
 This package, which is required for UBOOT_TEST_04_03 provides a single procedure which
 scans the PHYs and returns the link status with respect to the speed, autonegotiation,
 duplex, etc. The proc is:
 linktest		:This proc scans the PHY's and gets the status
 
 2.3.11) mv_networktest.tcl :
 ============================
 provides package 	:mv_networktest
 requires package 	:mv_serial_port
 			:mv_uboot_utils
 This package, which is required for UBOOT_TEST_04_05, provides a procedure which causes
 the board to ping another machine, the ip address of which is provided in the 
 uboot_test_04.txt file. The status of the machine (alive/not alive) is given as o/p.
 The proocedure is :
 network_test		:This proc causes the board to ping another machine and check
 			if a network path exists between them

 2.3.12) mv_dhcp_test.tcl :
 ==========================
 provides package 	:mv_dhcp_test
 requires package	:mv_serial_port
 			:mv_uboot_utils
			:mv_environment
 This package  is required for UBOOT_TEST_04_04. It consists of a single procedure
 dhcp_test		: It causes the board to send out a dhcp request and check
 			whether the request has been served or not.
 			
 2.3.13) mv_tftptest.tcl :
 =========================
 provides package 	:mv_tftptest
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftp_test_01 {only if UBOOT_TEST_04_06_01 is to be performed}
 			:mv_tftp_test_02 {only if UBOOT_TEST_04_06_02 is to be performed}
 			:mv_tftp_test_03 {only if UBOOT_TEST_04_06_03 is to be performed}
 			:mv_tftp_test_04 {only if UBOOT_TEST_04_06_04 is to be performed}
 			:mv_tftp_test_05 {only if UBOOT_TEST_04_06_05 is to be performed}
 			:mv_tftp_test_06 {only if UBOOT_TEST_04_06_06 is to be performed}
 			:mv_tftp_test_07 {only if UBOOT_TEST_04_06_07 is to be performed}
 			:mv_tftp_test_08 {only if UBOOT_TEST_04_06_08 is to be performed}
 This package provides procedures required for UBOOT_TEST_04_06 : Tftp tests. These are:
 tftp_test		:It calls the procedure corresponding to the sub-test requested for 
 send_tftp_cmd		:It sends out the tftp command to the board with the arguments
 			specified by the calling procedure. It returns 1 if file transfer
 			is successful, else 0. The actual commands sent out and the response
 			are logged in the tftp_log.txt file. The output is also made
 			available in the tftp_result global variable.
 			
 2.3.14) mv_tftp_01.tcl :
 ========================
 provides package	:mv_tftp_test_01
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 This package, required for UBOOT_TEST_04_06_01 (tftp test : Details can be found in the
 uboot test plan) consists of a single procedure :
 tftp_test_01		:It sets the tftp server ip address and calls the send_tftp_cmd
 			procedure with suitable parameters (load address and filename) 
 			
 2.3.15) mv_tftp_02.tcl :
 ========================
 provides package	:mv_tftp_test_02
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 This package, required for UBOOT_TEST_04_06_02 (tftp test : Details can be found in the
 uboot test plan) consists of a single procedure :
 tftp_test_02		:It sets the tftp server ip address and calls the send_tftp_cmd
 			procedure with suitable parameters (load address)  
 
 2.3.16) mv_tftp_03.tcl :
 ========================
 provides package	:mv_tftp_test_03
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 This package, required for UBOOT_TEST_04_06_03 (tftp test : Details can be found in the
 uboot test plan) consists of a single procedure :
 tftp_test_03		:It sets the tftp server ip address and calls the send_tftp_cmd
 			procedure with suitable parameters (filename)
 			
 2.3.17) mv_tftp_04.tcl :
 ========================
 provides package	:mv_tftp_test_04
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 This package, required for UBOOT_TEST_04_06_04 (tftp test : Details can be found in the
 uboot test plan) consists of a single procedure :
 tftp_test_04		:It sets the tftp server ip address and calls the send_tftp_cmd
 			procedure with suitable parameters (No arguments at all)
 			
 2.3.18) mv_tftp_05.tcl :
 ========================
 provides package	:mv_tftp_test_05
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 This package, required for UBOOT_TEST_04_06_05 (tftp test : Details can be found in the
 uboot test plan) consists of a single procedure :
 tftp_test_05		:It sets the tftp server ip address and calls the send_tftp_cmd
 			procedure with suitable parameters. The parametersare not critical
 			here, but the network link has to be discoonected for this test
 			A message regarding the same is given by this procedure
 			
 2.3.19) mv_tftp_06.tcl :
 ========================
 provides package	:mv_tftp_test_06
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 This package, required for UBOOT_TEST_04_06_06 (tftp test : Details can be found in the
 uboot test plan) consists of a single procedure :
 tftp_test_06		:It sets the tftp server ip address and calls the send_tftp_cmd
 			procedure with suitable parameters(load address and a wrong filename) 
 			
 2.3.20) mv_tftp_07.tcl :
 ========================
 provides package	:mv_tftp_test_07
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 This package, required for UBOOT_TEST_04_06_07 (tftp test : Details can be found in the
 uboot test plan) consists of a single procedure :
 tftp_test_07		:It seletes the tftp server ip address and calls the send_tftp_cmd
 			procedure with suitable parameters (These are not critical, since
 			anyways, an error message is expected)
 2.3.21) mv_tftp_08.tcl :
 ========================
 provides package	:mv_tftp_test_08
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 This package, required for UBOOT_TEST_04_06_08 (tftp test : Details can be found in the
 uboot test plan) consists of a single procedure :
 tftp_test_08		:It sets the tftp server ip address and calls the send_tftp_cmd
 			procedure with suitable parameters (These are not critical, since
 			anyways, an erroe message is expected)
 			
 2.3.22) mv_boot.tcl :
 =====================
 provides package 	:mv_boot
 requires package	:mv_serial_port
 			:mv_uboot_utils
 This package is required for UBOOT_TEST_04_08 : boot test. It consists of a single 
 procedure given below:
 boot			:sends out the boot command to the DUT and checks if the kernel
 			starts followed by the uncompressing of Linux
 			
 2.3.23) mv_uboot_test_07.tcl :
 ==============================
 provides package 	:mv_uboot_test_07
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_memcopy_ram {only if UBOOT_TEST_07_01/03 is to be performed}
 			:mv_memcopy_flash {only if UBOOT_TEST_07_02 is to be performed}
 			:mv_tftp_memcopy {only if UBOOT_TEST_07_04 is to be performed}
 			:mv_reset_time {only if UBOOT_TEST_07_05 is to be performed}
 This package contains procedures to handle tests in UBOOT_TEST_07 test class listed
 in the uboot_test_07.txt file. These procedures are:
 test_07_info 		:This proc accepts a test case id and returns a suitable string
 			which decides the further course of action
 uboot_test_07 		:This proc calls various procedures required to carry out all
 			the tests in UBOOT_TEST_07 class
 			Directives if any are handled by calling the isdirective proc
 			
 			
 2.3.24) mv_reset_time.tcl:
 ==========================
 provides package 	:mv_reset_time
 requires package	:mv_serial_port
 			:mv_uboot_utils
 This package is required for UBOOT_TEST_07_05. It consists of a single procedure
 reset_time		:It causes the DUT to reset a number of times (number specified
 			in uboot_test_07.txt file or set to a default value 3) and
 			calculates the average time required for the DUT to reset and
 			arrive at the u-boot prompt
 			
 2.3.25) mv_env_value_test.tcl:
 ==============================
 provides package	:mv_env_value_test
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_environment
 This package is required for UBOOT_TEST_03_17. It consists of a single procedure
 env_value_test		:It gets the name of the variable form the uboot_test_03.txt file and if it
 			is found in the u-boot environment, returns its value in the result. If an
 			expected value is also mentioned in the file, this proc compares it with the
 			actual value and gives the result as Pass if it matches
 			
 2.3.26) mv_initialise.tcl:
 ==========================
 provides package	:mv_initialise
 requires package	:N/A
 This package consists of a single procedure initialise
 initialise		:This procedure has to be called form the main U-boot test script. It reads the
 			config.txt file and sets the global variables as per the values found. If the
 			values are not available in the file, the variables are set to their default
 			values.
 			
 2.3.27) mv_runtest.tcl:
 =======================
 provides package	:mv_runtest
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_environment
 This package, required by the UBOOT_TEST_04_07 test case consists of a single procedure:
 runtest		: It sets a variable to contain a few commands and then issues the "run"
 			command with the variable's name as the argument. The commands in the variable
 			then get executed
 			
 2.3.28) mv_uboot_upgrade.tcl:
 =============================
 provides package	:mv_uboot_upgrade
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_environment
 This package provides a procedure for UBOOT_TEST_04_09 (U-boot upgrade test)
 uboot_upgrade		:This procedure issues the "bubt" command which copies the u-boot.bin file
			via tftp, burns it onto flash and resets the board so that the new u-boot
 			version loads. The serverip and u-boot image name can be specified in the
 			uboot_test_04.txt file, else the defaults ($serverip global variable and 
 			u-boot.bin)
 			
 2.3.29) mv_ramtest.tcl:
 =======================
 provides package	:mv_ramtest
 requires package	:mv_serial_port
 			:mv_uboot_utils
 This package provides the ramtest procedure required or UBOOT_TEST_04_10
 ramtest		:This procedure issues the "mtest" u-boot command which writes and reads back
 			values form RAM. the number of locations to be written to/ read from can be
 			specified in the uboot_test_04.txt file, else the default of 100 is used
 			
 2.3.30) mv_uboot_test_06.tcl :
 ==============================
 provides package 	:mv_uboot_test_06
 requires package	:mv_serial_port
 			:mv_uboot_utils
 			:mv_reset_stresstest
 This package contains procedures to handle tests in UBOOT_TEST_06 test class listed
 in the uboot_test_06.txt file. These procedures are:
 test_06_info 		:This proc accepts a test case id and returns a suitable string
 			which decides the further course of action
 uboot_test_06 		:This proc calls various procedures required to carry out all
 			the tests in UBOOT_TEST_06 class
 			Directives if any are handled by calling the isdirective proc
 			
 2.3.31) mv_reset_stresstest.tcl:
 ================================
 provides package	:mv_reset_stresstest
 requires package	:mv_serial_port
 			:mv_uboot_utils
 This package consist of a single procedure required for UBOOT_TEST_06_01 (Reset Stress Test)
 reset_stresstest	:It resets the DUT a large number of times, each time testing whether the
 			prompt appears. The number of iterations to be performed is provided in the
 	
 2.3.32) mv_memcopy_flash.tcl:
 ==============================
 provides package	:mv_memcopy_flash
 requires package	:mv_uboot_utils
 			:mv_serial_port	
 This package is required by the memory copy timings related tests involving copying to flash in
 UBOOT_TEST_07 test class. It consists of 3 procedures:
 memcopy_flash	: It erases the flash and then copies data from RAm to the region erased.
 flash_erase	: This procedure sends out the actual command required for erasing the flash
 flash_write	: This procedure sends out the actual command to write to flash and calculates the
 		time requiredfor the cpy and returns that value
 
 2.3.33) mv_memcopy_ram:
 ========================
 provides package	:mv_memcopy_ram
 requires package	:mv_serial_port
 			:mv_uboot_utils
 This package is required y the memory copy timings related tests involving RAM in UBOOT_TEST_07 
 test class. It consists of a single procedure memcopy_ram
 memcopy_ram	: This procedure copies data from RAM to RAM or Flash to RAM depending on the 
 		testcaseid passed to it. It calculates the time required for the copy to take place
 		
 2.3.34) mv_tftp_memcopy.tcl:
 =============================
 provides package	:mv_tftp_memcopy
 requires package	:mv_uboot_utils
 			:mv_tftptest
 			:mv_environment
 			:mv_serial_port
 This package, consisting of a single procedure, is used by UBOOT_TEST_07_04 which calculates the
 time required to get a particular file via TFTP. Default is a 1MB test file named 1mbtestfile which,
 if present on the tftpserver, gives the time for 1MB
 tftp_memcopy	: This procedure gets a file from a TFTP server and calculates the time required for
 		copying it. The timing may be quite inaccurate due to the limitation of the baudrate,
 		i.e.the file may get copied quickly, but it may require some more time to actually
 		display the status on the console
 
 2.3.35) mv_version.tcl:
 ========================
 provides package	:mv_version
 requires package 	:mv_uboot_utils
			:mv_serial_port
 This package, consisiting of a single procedure, is used by UBOOT_TEST_03_03 which checks the U-boot
 version on the board. The procedure is:
 version_test	: It issues the "version" command and sends its output as the result


 3) TEST FILES :
 ===============
 -This section explains how to write a test file (uboot_test_xx.txt)
 -Each test class has its own test file.
 -The test files has a list of all tests to be performed.
 -The list contains of test case ids of the test cases, one on each line.
 -Arguments, if any, are written on the same line as the id, separated
  by white space.
 -Any single argument cannot contain any white spaces in between
 -Blank lines are simple ignored.
 -Directives can be placed anywhere in the test file, but on a new line
 -Following are the samples of all the test files. All tests have been included.
  Arguments, if required are also mentioned. The arguments written in curly braces "{}"
  are optional arguments. If they are not given, some defaults are used
  
 3.1) uboot_test_03.txt
 =======================
 UBOOT_TEST_03_01
 UBOOT_TEST_03_02
 UBOOT_TEST_03_03
 UBOOT_TEST_03_04
 UBOOT_TEST_03_05
 UBOOT_TEST_03_06
 UBOOT_TEST_03_07
 UBOOT_TEST_03_08
 UBOOT_TEST_03_09
 UBOOT_TEST_03_10
 UBOOT_TEST_03_11
 UBOOT_TEST_03_12
 UBOOT_TEST_03_13
 UBOOT_TEST_03_14
 UBOOT_TEST_03_15
 UBOOT_TEST_03_16
 UBOOT_TEST_03_17 stderr network
 UBOOT_TEST_03_17 stdin serial
 UBOOT_TEST_03_18


 3.2) uboot_test_04.txt
 =======================
 UBOOT_TEST_04_01_01 myVar {myVal1}
 UBOOT_TEST_04_01_02 myVar {myVal2}
 UBOOT_TEST_04_01_03 myVar {myVal3}
 UBOOT_TEST_04_02_01 myVar
 set myVar myVal
 UBOOT_TEST_04_02_02 myVar
 UBOOT_TEST_04_02_03 myVar
 UBOOT_TEST_04_03
 UBOOT_TEST_04_04 192.168.2.1
 UBOOT_TEST_04_05
 set ipaddr 192.168.2.2
 save
 UBOOT_TEST_04_06_01 192.168.2.1 0 abc.txt
 UBOOT_TEST_04_06_02 192.168.2.1 abc.txt
 UBOOT_TEST_04_06_03 192.168.2.1 0
 UBOOT_TEST_04_06_04 192.168.2.1
 UBOOT_TEST_04_06_05 192.168.2.1 0 abc.txt
 UBOOT_TEST_04_06_06 192.168.2.1 0
 UBOOT_TEST_04_06_07
 UBOOT_TEST_04_06_08 192.168.2.1
 UBOOT_TEST_04_07
 UBOOT_TEST_04_09 192.168.2.1 u-boot.bin
 UBOOT_TEST_04_10 200
 

 3.3) uboot_test_06.txt
 =======================
 UBOOT_TEST_06_01
 
 3.3) uboot_test_07.txt
 =======================
 UBOOT_TEST_07_01 {0} {10000} {100000}
 UBOOT_TEST_07_02
 UBOOT_TEST_07_03
 UBOOT_TEST_07_04 
 UBOOT_TEST_07_05 5


 NOTE : In places where more than one optional arguments exists, if you want to give the
 second or later argument, you must also provide all arguments prior to that
 Eg. The UBOOT_TEST_07_01 has 3 optional arguments, SOURCE_ADDR, DEST_ADDR, SIZE, in
 that order. If you want to provide the SIZE, you also need to provide SOURCE_ADDR and
 DEST_ADDR
 
 4) DIRECTIVES :
 ===============
 Directives in the test files are handled by the "isdirective" procedure which is a part
 of the mv_uboot_utils package
 The directives currently supported are :
 
 set		: This requires two arguments, variable name and value, in that order
 		It sets up a u-boot variable with the given name and value
 save		: Saves the current environment onto non-volatile memory (Flash)
 delete		: Requires 1 argument, the variable name. It deletes the u-boot variable
 		of the name provided
 reset		:reset the DUT
 cmd		:All the arguments following this directive are sent out as a single
 		command to the DUT. This directive does not check whether the command 
 		and its arguments are correct or not
 

 5) CONFIG FILE	:
 =================
	The config.txt file defines the configuration to be used and is also used to assign
 values to some global variables. each line in the config.txt file must have the format:
 varname=varvalue, where varname can be any of the following:

 port
 baud
 boot_prompt
 auto
 serverip
 tftpfilename
 flash_mem_addr
 uboot_test_01
 uboot_test_02
 uboot_test_03
 uboot_test_04
 uboot_test_05
 uboot_test_06
 uboot_test_07

 Note that varname and varvalue are separated by a single "=" sign and nothing else
 If any line begins with "#", it is considered as a comment and hence ignored
 Use double inverted commas in case any of the varvalue has any white spaces
 Eg. boot_prompt="U-boot>> "

 6) COMMAND LINE OPTIONS :
 =========================
	You may use certain command line options to override the settings in the config.txt file
 The valid command line options are:
 port
 baud
 boot_prompt
 auto
 tftpfilename
 serverip
 
 Use double inverted commas if any of the value has any white spaces
 The command line options can be specified as follows:
 #~ ./ubootTest.tcl auto=1 baud=38400 boot_prompt="U-boot>> " 

 7) RULES FOR ADDING NEW SCRIPTS :
 ==================================
 - Filename must always begin with "mv_" followed by suitable characters and ".tcl" extension
 - Each file must begin with follwing text :
 #######################################################################
 # mv_xxxxx.tcl --
 #
 #       Short description about the contents of the file
 #
 # Author:
 #       Author's name (email id)
 # Log:
 #       date      Name     Changes/addition 
 #
#######################################################################
- This must be followed by a list of packages required by this file, and the package
  it provides. Example (mv_ent_test_01.tcl) :
  
  package require mv_serial_port
  package require mv_uboot_utils
  package require mv_environment
  package provide mv_env_test_01 1.0

 - Each procedure in a file should begin with the following text :
 #######################################################################
 # name of procedure
 #
 # Short description regarding the purpose of this procedure
 #
 # Parameters:
 #       param 1 : Description of param 1
 #       param 2 : Description of param 2, and so on     
 # Return:
 #       Return value : Description
 # Example:
 #       An example showing how to use the procedure
 # Comments:
 #       Comments, if any, about the procedure
 #######################################################################

 - If there are no parameters required, no return value or no comments, write N/A in
   front of it
 - This should be followed by the actual procedure beginning with "proc ..."
 
 8) HOW TO USE THE TEST SUITE :
 ==============================
 Hardware required :
   1. A laptop/Desktop with UART connectivity
   2. Null modem cable
   3. The board to be tested (DUT)
   4. UART connector for the board
   5. Network cable
   6. Power supply
   
 Software required :
   1. Tcl (I have used tcl-8.4.15)
   2. The requisite tcl files viz. ubootTest.tcl, uboot_test_xx.tcl for the test class
      to which the test belongs, library files required for the test
   3. TFTP server running on the host machine
   4. DHCP server running somewhere on the network to which the DUT is connected
   4. The "tftptestfile" and "1mbtestfile" must be available on the tftp server
   5. "Please make the necessary changes in the config.txt file as per your requirements"

 You must have read/write permissions for the serial port. If you don't have execute 
 the following on command line as root (on Linux machines only)
 $ chmod a+rw /dev/ttyS0
 Replace ttyS0 by the actual port you are using
 
 Steps :
 =======
 - Switch on the Desktop/Laptop
 - Connect the null modem cable (DB9) to it's serial port. Use a USB to serial converter
   if no serial port is available on your machine.
 - Connect the other end of the cable to the DUT's UART
 - Go to the folder where the ubootTest.tcl script is located
 - It must also have the uboot_test_xx.txt files as required and the lib/ folder with
   all library files
 - Modify the config.txt file as required
 - Execute the script
   $ ./ubootTest.tcl
 - You may use the command line options if required
 - When you get the message "Swich on the board", please switch on the DUT
 - The tests will then start
 - The testcaseid of the test being currently performed appears on the console and when
   it is completed, it says "done" followed by the next test
 - Some test (like UBOOT_TEST_04_06_05) need some user interaction. What the user is 
   expected to do will be displayed on the console
 - Refer the "uboot_test_results.txt" for results

