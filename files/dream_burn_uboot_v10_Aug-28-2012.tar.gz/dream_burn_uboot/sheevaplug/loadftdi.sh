iptables -F
/etc/init.d/network restart
insmod /lib/modules/`uname -r`/kernel/drivers/usb/serial/usbserial.ko
insmod /lib/modules/`uname -r`/kernel/drivers/usb/serial/ftdi_sio.ko vendor=0x9e88 product=0x9e8f
